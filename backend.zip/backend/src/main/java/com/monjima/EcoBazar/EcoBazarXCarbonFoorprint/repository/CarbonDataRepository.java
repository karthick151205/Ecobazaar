package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint.repository;

public interface CarbonDataRepository {
}
