package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint.entity;

public class Category {
}
