package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint.service;

public class CarbonDataService {
}
