package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint.entity;

public enum Role {
    USER,
    ADMIN,
    SELLER
}
