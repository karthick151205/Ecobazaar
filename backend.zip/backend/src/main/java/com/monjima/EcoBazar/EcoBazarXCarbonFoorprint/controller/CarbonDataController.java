package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint.controller;

public class CarbonDataController {
}
