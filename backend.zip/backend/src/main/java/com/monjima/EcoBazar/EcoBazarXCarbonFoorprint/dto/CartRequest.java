package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint.dto;

public class CartRequest {
}
