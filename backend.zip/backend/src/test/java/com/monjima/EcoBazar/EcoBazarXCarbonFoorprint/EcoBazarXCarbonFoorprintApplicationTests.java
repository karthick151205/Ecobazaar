package com.monjima.EcoBazar.EcoBazarXCarbonFoorprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoBazarXCarbonFoorprintApplicationTests {

	@Test
	void contextLoads() {
	}

}
